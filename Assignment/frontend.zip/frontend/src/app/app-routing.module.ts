import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentComponent } from "./student/student.component";
import { DeparmentComponent } from "./department/department.component";

const routes: Routes = [
  { path: 'student', component: StudentComponent },
  { path: 'department', component: DeparmentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component } from '@angular/core';

@Component({
  selector: 'app-deparment',
  templateUrl: './deparment.component.html',
  styleUrls: ['./deparment.component.css']
})
export class DeparmentComponent {

}
